#include <MIDILAR.h>
#include <iostream>

int main() {
    std::cout << "Using MIDILAR v" << MIDILAR_VERSION << std::endl << std::endl;

    std::cout << "Enabled Modules:" << std::endl << std::endl;

    bool modulesEnabled = false; // Track if any module is enabled

    #ifdef MIDILAR_SYSTEM_FOUNDATION
        modulesEnabled = true;
        std::cout << "  - SystemFoundation." << std::endl;

        std::cout << "    - CallbackHandler." << std::endl;
        std::cout << "    - System Clock." << std::endl;
        std::cout << std::endl;
    #endif // MIDILAR_SYSTEM_FOUNDATION

    #ifdef MIDILAR_DSP_FOUNDATION
        modulesEnabled = true;
        std::cout << "  - dspFoundation." << std::endl;
        
        #ifdef MIDILAR_GENERATORS
            std::cout << "    - Generators." << std::endl;

            std::cout << "        - Periodic." << std::endl;
            std::cout << "        - Shaping." << std::endl;
            std::cout << "        - Windowing." << std::endl;
            std::cout << "        - Envelopes." << std::endl;
        #endif // MIDILAR_GENERATORS

        #ifdef MIDILAR_LUT
            std::cout << "    - LUT." << std::endl;

            #ifdef MIDILAR_LUT1D
                std::cout << "        - LUT1D." << std::endl;
            #endif // MIDILAR_LUT1D
            
            #ifdef MIDILAR_LUT2D
                std::cout << "        - LUT2D." << std::endl;
            #endif // MIDILAR_LUT2D
            
            #ifdef MIDILAR_LUT3D
                std::cout << "        - LUT3D." << std::endl;
            #endif // MIDILAR_LUT3D

            #ifdef MIDILAR_LUT_PERIODIC
                std::cout << "        - Periodic." << std::endl;
                
                std::cout << "            - Sine." << std::endl;
                std::cout << "            - Triangle." << std::endl;
                std::cout << "            - Square." << std::endl;
                std::cout << "            - Saw." << std::endl;
            #endif // MIDILAR_LUT_PERIODIC

            #ifdef MIDILAR_LUT_SHAPING
                std::cout << "        - Shaping." << std::endl;

                std::cout << "            - LogExp1D." << std::endl;
                std::cout << "            - LogExp2D." << std::endl;
                std::cout << "            - LogExp3D." << std::endl;
            #endif // MIDILAR_LUT_SHAPING
        #endif // MIDILAR_LUT
        std::cout << std::endl;
    #endif // MIDILAR_AUDIO_FOUNDATION

    #ifdef MIDILAR_MIDI_FOUNDATION
        modulesEnabled = true;
        std::cout << "  - MidiFoundation." << std::endl;

        std::cout << "    - Protocol Enums." << std::endl;
        std::cout << "    - Message." << std::endl;
        std::cout << "    - MessageParser." << std::endl;
        std::cout << "    - Note." << std::endl;
        std::cout << "    - DeviceBase." << std::endl;
        std::cout << std::endl;
    #endif // MIDILAR_MIDI_FOUNDATION

    
    #ifdef MIDILAR_MIDI_DEVICES
        modulesEnabled = true;
        std::cout << "  - MidiDevices." << std::endl;

        #ifdef MIDILAR_MIDI_DEVICES_CHANNEL_REASSIGN
            std::cout << "    - Channel Reassign." << std::endl;
        #endif // MIDILAR_MIDI_DEVICES_CHANNEL_REASSIGN
        
        #ifdef MIDILAR_MIDI_DEVICES_VELOCITY_SHAPER
            std::cout << "    - Velocity Shaper." << std::endl;
        #endif // MIDILAR_MIDI_DEVICES_VELOCITY_SHAPER
        

    #endif // MIDILAR_MIDI_DEVICES

    if (!modulesEnabled) {
        std::cout << "  No modules enabled." << std::endl;
    }

    std::cout << std::endl << std::endl;

    return 0;
}