set(MIDILAR_DOXYGEN_PREDEFS "")
set(MIDILAR_DOXYGEN_INPUTS "")

function(midilar_add_macro visibility)
    target_compile_definitions(MIDILAR ${visibility} ${ARGN})
    list(APPEND MIDILAR_DOXYGEN_PREDEFS ${ARGN})
    set(MIDILAR_DOXYGEN_PREDEFS "${MIDILAR_DOXYGEN_PREDEFS}" PARENT_SCOPE)
endfunction()

function(midilar_add_dox)
    list(APPEND MIDILAR_DOXYGEN_INPUTS ${ARGN})
    set(MIDILAR_DOXYGEN_INPUTS "${MIDILAR_DOXYGEN_INPUTS}" PARENT_SCOPE)
endfunction()

